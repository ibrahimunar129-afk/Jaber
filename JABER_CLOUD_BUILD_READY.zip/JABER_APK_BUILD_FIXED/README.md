# JABER — AndroidIDE APK Build Package

This package is prepared for AndroidIDE.

Build launcher:
- `gradlew` uses `/bin/sh` so AndroidIDE's build runner does not fail on the old `/system/bin/sh` interpreter.
- It calls AndroidIDE's installed Gradle and passes the AndroidIDE AAPT2 override.
- The project contains Customer, Professional, and Manager modules.

Important: this package is source/build-ready; the APK itself must be produced by an Android build environment with the Android SDK/Gradle dependencies available.
