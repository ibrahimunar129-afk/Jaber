# JABER Cloud APK Build

This project is configured to build the three JABER Android APKs in GitHub Actions without AndroidIDE.

Apps produced:
- Jaber-Customer.apk
- Jaber-Professional.apk
- Jaber-Manager.apk

Workflow: `.github/workflows/build-apk.yml`

The workflow installs Android SDK 34, uses JDK 17 and Gradle 8.7, then runs `assembleRelease` and uploads all three APKs as a single build artifact named `Jaber-APKs`.
