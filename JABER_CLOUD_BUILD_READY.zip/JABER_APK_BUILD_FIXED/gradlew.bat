@echo off
where gradle >nul 2>nul
if %errorlevel% neq 0 (
  echo JABER: Gradle is not available in PATH.
  exit /b 127
)
gradle %*
